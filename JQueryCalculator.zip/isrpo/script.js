$(document).ready(function() { // Ждём загрузки страницы	   
	$("input[name=send]").click( function () { // Событие нажатия на кнопку "Расчёт"
		var action = $("select[name=action]").val(); // Получаем значение действия, которое нужно выполнить
		var first = $("input[name=first]").val() * 1; // Переменная первого числа
		var second = $("input[name=second]").val() * 1; // Переменная второго числа
		var result;
        var ochist;
       
		if (action == '+') { // Если действие - сложение
			result = first + second; //  складываем
		}
		else if (action == '-'){ // Если действие вычитание
			result = first - second; // вычитаем
		}
		else if (action == '*'){ // Если действие умножение
			result = first * second; // умножаем
		}
		else if (action == '/'){ // Если действие деления
			result = first / second; // делим
		}
        else if (action == 'Остаток'){ // Если действие деления
			result = first % second; // делим
		}
        else if (action == 'Степень'){ // Если действие деления
			result = first ** second; // делим
		}
        else if (action == 'Корень'){ // Если действие деления
			result = Math.sqrt(first); // делим
		}
       
		$("input[name=result]").val(result); // записываем результат
	});
    $("input[name=OCH]").click( function (){
        $("input[name=first]").val('');
        $("input[name=second]").val('');
        $("input[name=result]").val('');
    });
    $("input[name=TOC2]").click( function (){
        second = $("input[name=second]").val() * 1;
        var ek=Number(second+'.0')
       ek=ek.toFixed(1);
       
       ek=ek.slice(0,-1);
        $("input[name=second]").val(ek);
    });
    $("input[name=TOC]").click( function (){
        first = $("input[name=first]").val() * 1;
        var sk=Number(first+'.0')
       sk=sk.toFixed(1);
       
       sk=sk.slice(0,-1);
        $("input[name=first]").val(sk);
    });
  
});
